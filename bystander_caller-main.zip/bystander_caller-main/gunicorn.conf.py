# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Ikhlas

bind = "0.0.0.0:10000"
workers = 4
threads = 2
timeout = 120