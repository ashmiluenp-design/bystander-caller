# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Ikhlas

# Configuration settings for the application
